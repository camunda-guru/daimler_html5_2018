window.addEventListener('load',function()
{
   // alert("loaded...");

   var aRef=document.getElementById("register");

   aRef.addEventListener('click',function()
   {
       window.open('register.html','regForm','width=800 height=500 left=200');
   })

})
