window.addEventListener('load',function()
{
    var canvasRef=document.getElementById("smiley");
    var context=canvasRef.getContext('2d');

    var centerX=canvasRef.width/2;
    var centerY=canvasRef.height/2;
    context.beginPath();
    context.arc(centerX,centerY,40,0,2*Math.PI,false);
    //context.lineWidth=5;
    context.fillStyle='yellow';
    context.fill();
    context.closePath();
    context.beginPath();
    context.arc(centerX-15,centerY-10,5,0,2*Math.PI,false);
    context.fillStyle='black';
    context.fill();
    context.closePath();
    context.beginPath();
    context.arc(centerX+15,centerY-10,5,0,2*Math.PI,false);
    context.fillStyle='black';
    context.fill();
    context.closePath();
    context.beginPath();
    context.arc(centerX,centerY+10,20,0,Math.PI,false);
    context.stroke();
    context.closePath()


    canvasRef=document.getElementById("olympic");
    context=canvasRef.getContext('2d');

    centerX=canvasRef.width/2;
    centerY=canvasRef.height/2;

    var colorArray=new Array("black","blue","yellow");
    var x=0,y=0;
    for(var i=0;i<3;i++) {

        context.beginPath();
        context.arc(centerX+x, centerY+y, 25, 0, 2 * Math.PI, false);
        x=40;
        context.strokeStyle=colorArray[i];
        context.lineWidth=3
        context.stroke();
        context.closePath();
    }
})
